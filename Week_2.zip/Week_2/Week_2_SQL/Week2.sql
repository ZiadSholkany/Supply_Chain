use Supply

select * from supply_chain_data

--What is the total Revenue based on location?
select Location, SUM(Revenue_generated) as Total_Revenue  from supply_chain_data 
group by Location 
order by Location desc

--What is the total cost for each transportation mode?
select Transportation_modes ,sum(Costs) as Total_Cost  from supply_chain_data
group by Transportation_modes

--What are the best-selling products?
select SKU,Product_type,sum(Number_of_products_sold) as Total_Sold from supply_chain_data
group by SKU,Product_type
order by Total_Sold desc

--Which suppliers have the most delivery delays?
select Supplier_name,AVG(Lead_time) Avg_lead_time from supply_chain_data
group by Supplier_name
order by Avg_lead_time

--How can we identify the orders with the highest shipping costs?
select SKU,Product_type,Shipping_costs from supply_chain_data
order by Shipping_costs desc
--How many orders are ordered based on Customer Demographics?
select Customer_demographics,count(Product_type) Num_Orders from supply_chain_data
group by  Customer_demographics

--What is the defect rate per product based on average manufacturing cost?
select Product_type,count(Production_volumes) Total_Production_volumes ,
Avg(Manufacturing_costs)Avg_Manufacturing_costs,AVG(Defect_rates) Avg_Defect_rates from supply_chain_data
group by Product_type
order by Total_Production_volumes desc 